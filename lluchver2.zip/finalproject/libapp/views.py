from django.shortcuts import render, redirect
from django.utils import timezone
from datetime import timedelta, datetime
from .models import Book

def borrow_book(request):
    if request.method == "POST":
        accession_number = request.POST.get('accession_number')
        
        try:
            # Find the book by accession number (case-insensitive)
            book = Book.objects.get(accession_number__iexact=accession_number)
            
            # If the book is available, borrow it
            if book.status == 'available':
                book.status = 'borrowed'
                book.date_borrowed = timezone.now().date()  # Set current date
                book.days_remaining = 5  # Default to 5 days remaining
                book.save()

                return redirect('view books')  # Redirect to view books page
            else:
                # If the book is already borrowed, display an error message
                return render(request, 'libapp/borrow_book.html', {'error': 'This book is already borrowed.'})
        
        except Book.DoesNotExist:
            # If the accession number doesn't exist, show an error message
            return render(request, 'libapp/borrow_book.html', {'error': 'Invalid accession number.'})
    
    return render(request, 'libapp/borrow_book.html')


def view_books(request):
    # Get all borrowed books (those with status 'borrowed')
    borrowed_books = Book.objects.filter(status='borrowed')

    # Get the current date (this will be used to calculate days remaining)
    current_date = timezone.now().date()  # Convert timezone.now() to date

    for book in borrowed_books:
        if book.date_borrowed:
            book.return_date = book.date_borrowed + timedelta(days=book.days_remaining)
        else:
            book.return_date = None
            
            # Calculate the return date as date_borrowed + 5 days
            return_date = (book.date_borrowed + timedelta(days=5)).date()  # Ensures return_date is a date object

            # Calculate days remaining
            days_left = (return_date - current_date).days
            book.days_remaining = max(days_left, 0)  # Ensure days_remaining doesn't go negative

            # Check if the book is overdue
            if days_left <= 0:
                book.status = 'overdue'  # Update status to 'overdue'

            # Save the updated book status and days_remaining
            book.save()

    # Render the page with the updated list of books
    return render(request, 'libapp/view_books.html', {'books': borrowed_books})
