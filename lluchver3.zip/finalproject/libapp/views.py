from django.shortcuts import render, redirect
from django.utils import timezone
from datetime import timedelta, datetime
from .models import Book

def borrow_book(request):
    if request.method == "POST":
        accession_number = request.POST.get('accession_number')
        
        try:
            # Find the book by accession number (case-insensitive)
            book = Book.objects.get(accession_number__iexact=accession_number)
            
            # If the book is available, borrow it
            if book.status == 'available':
                book.status = 'borrowed'
                book.date_borrowed = timezone.now().date()  # Set current date
                book.days_remaining = 5  # Default to 5 days remaining
                book.save()

                return redirect('view books')  # Redirect to view books page
            else:
                # If the book is already borrowed, display an error message
                return render(request, 'libapp/borrow_book.html', {'error': 'This book is already borrowed.'})
        
        except Book.DoesNotExist:
            # If the accession number doesn't exist, show an error message
            return render(request, 'libapp/borrow_book.html', {'error': 'Invalid accession number.'})
    
    return render(request, 'libapp/borrow_book.html')

def binary_search(books, query, key=lambda book: book.title):
    """
    Binary search implementation to search for books by the specified key (e.g., title, author, publisher).
    Returns all books that match the search query.
    """
    low, high = 0, len(books) - 1
    matched_books = []

    while low <= high:
        mid = (low + high) // 2
        current_value = key(books[mid]).lower()
        
        if current_value == query.lower():  # Case insensitive search
            # Add this book to the matched list
            matched_books.append(books[mid])
            
            # Check for other matches to the left and right of mid
            # Check to the left
            left = mid - 1
            while left >= 0 and key(books[left]).lower() == query.lower():
                matched_books.append(books[left])
                left -= 1
            
            # Check to the right
            right = mid + 1
            while right < len(books) and key(books[right]).lower() == query.lower():
                matched_books.append(books[right])
                right += 1
            break
        elif current_value < query.lower():
            low = mid + 1
        else:
            high = mid - 1

    return matched_books



def view_books(request):
    # Get all borrowed books (those with status 'borrowed')
    borrowed_books = Book.objects.filter(status='borrowed')

    # Get the current date (this will be used to calculate days remaining)
    current_date = timezone.now().date()

    # Sort books based on user selection
    sort_field = request.GET.get('sort', 'title')  # Default to 'title' sorting
    if sort_field == 'title':
        borrowed_books = sorted(borrowed_books, key=lambda book: book.title.lower())
    elif sort_field == 'author':
        borrowed_books = sorted(borrowed_books, key=lambda book: book.author.lower())
    elif sort_field == 'publisher':
        borrowed_books = sorted(borrowed_books, key=lambda book: book.publisher.lower())

    # Apply binary search if search query is present
    search_query = request.GET.get('search', '')
    if search_query:
        # Call binary search to get all matched books
        search_results = binary_search(borrowed_books, search_query, key=lambda book: book.title)
        borrowed_books = search_results  # Only show the results that match the search query

    # Calculate return dates and days remaining for each book
    for book in borrowed_books:
        if book.date_borrowed:
            book.return_date = book.date_borrowed + timedelta(days=book.days_remaining)
        else:
            book.return_date = None

        # Calculate the return date as date_borrowed + 5 days
        return_date = (book.date_borrowed + timedelta(days=5)).date()
        days_left = (return_date - current_date).days
        book.days_remaining = max(days_left, 0)  # Ensure days_remaining doesn't go negative

        # Check if the book is overdue
        if days_left <= 0:
            book.status = 'overdue'

        # Save the updated book status and days_remaining
        book.save()

    # Render the page with the updated list of books
    return render(request, 'libapp/view_books.html', {
        'books': borrowed_books,
        'search_query': search_query,
        'sort_field': sort_field,
    })
