# test_binary_search.py

# Sample binary search function
def binary_search(arr, target, key=lambda x: x):
    left, right = 0, len(arr) - 1
    while left <= right:
        mid = (left + right) // 2
        mid_value = key(arr[mid])
        
        print(f"Searching... Left: {left}, Right: {right}, Mid: {mid}, Mid Value: {mid_value}")
        
        if mid_value == target:
            return arr[mid]
        elif mid_value < target:
            left = mid + 1
        else:
            right = mid - 1
    return None  # Return None if the item isn't found

# Sample Book class and data
class Book:
    def __init__(self, title, author):
        self.title = title
        self.author = author
    
    def __repr__(self):
        return f"Book(title={self.title}, author={self.author})"

# Sample list of books
books = [
    Book("Harry Potter", "J.K. Rowling"),
    Book("Lord of the Rings", "J.R.R. Tolkien"),
    Book("The Hobbit", "J.R.R. Tolkien"),
]

# Sort the books by title
sorted_books = sorted(books, key=lambda book: book.title.lower())

# Test binary search for a specific title
search_title = "The Hobbit"
result = binary_search(sorted_books, search_title.lower(), key=lambda book: book.title.lower())

if result:
    print(f"Found: {result}")
else:
    print("Not found.")
