import pandas as pd
from django.core.management.base import BaseCommand
from libapp.models import Book

class Command(BaseCommand):
    help = 'Load books from a CSV file into the database'

    def handle(self, *args, **kwargs):
        # Path to the CSV file
        csv_file_path = 'finalproject/data/dataset.csv'

        # Try reading the CSV file
        try:
            df = pd.read_csv(csv_file_path)
        except FileNotFoundError:
            print(f"File not found: {csv_file_path}")
            return

        # Iterate through the DataFrame and create or update Book instances
        for index, row in df.iterrows():
            # Handle the Volume conversion (only convert if it's a valid number)
            volume = int(row['Volume']) if pd.notnull(row['Volume']) and row['Volume'] != '' else None

            # Handle the Pages conversion (only convert if it's a valid number)
            pages = int(row['Pages']) if pd.notnull(row['Pages']) and row['Pages'] != '' else None

            # Use update_or_create to either update the existing record or create a new one
            book, created = Book.objects.update_or_create(
                isbn=row['ISBN'],  # Find or create based on ISBN
                defaults={
                    'accession_number': row['Accession Number'],
                    'author': row['Author'],
                    'title': row['Title'],
                    'edition': row['Edition'] if pd.notnull(row['Edition']) and row['Edition'] != '' else None,
                    'volume': volume,
                    'pages': pages,
                    'publisher': row['Publisher'],
                    'year': int(row['Year']) if pd.notnull(row['Year']) else None,
                }
            )

            # Print whether the book was created or updated
            if created:
                print(f"Created new book with ISBN: {row['ISBN']}")
            else:
                print(f"Updated existing book with ISBN: {row['ISBN']}")

        print("CSV data has been loaded into the Django database.")
