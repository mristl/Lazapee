from django.shortcuts import render, redirect
from django.utils import timezone
from .models import Book

def borrow_book(request):
    if request.method == "POST":
        accession_number = request.POST.get('accession_number')
        
        try:
            # Find the book by accession number (case-insensitive)
            book = Book.objects.get(accession_number__iexact=accession_number)
            
            # If the book is available, borrow it
            if book.status == 'available':
                book.status = 'borrowed'
                book.date_borrowed = timezone.now().date()  # Set current date
                book.days_remaining = 5  # Default to 5 days remaining
                book.save()

                return redirect('view books')  # Redirect to view books page
            else:
                # If the book is already borrowed, display an error message
                return render(request, 'libapp/borrow_book.html', {'error': 'This book is already borrowed.'})
        
        except Book.DoesNotExist:
            # If the accession number doesn't exist, show an error message
            return render(request, 'libapp/borrow_book.html', {'error': 'Invalid accession number.'})
    
    return render(request, 'libapp/borrow_book.html')


def view_books(request):
    # Get all books with 'borrowed' status
    borrowed_books = Book.objects.filter(status='borrowed')

    return render(request, 'libapp/view_books.html', {'books': borrowed_books})

