from django.contrib import admin
from .models import Employee, Payslip
# Register your models here.

admin.site.register(Employee)
admin.site.register(Payslip)