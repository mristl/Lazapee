from django.shortcuts import render
from .models import Book


# Create your views here.
def borrow_book(request):
    return render(request, 'libapp/borrow_book.html')

def view_books(request): 
    book_objects = Book.objects.all()
    return render(request, 'libapp/view_books.html',{'books': book_objects})





