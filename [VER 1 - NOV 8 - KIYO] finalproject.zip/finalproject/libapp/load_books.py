# myapp/management/commands/load_books.py

import pandas as pd
from django.contrib.auth.models import User
from .models import Book

# Read CSV file into a DataFrame
csv_file_path = 'finalproject\data\dataset.csv'
df = pd.read_csv(csv_file_path)

# Iterate through the DataFrame and create model instances
for index, row in df.iterrows():
    # Create or get the Category instance
    category, created = Category.objects.get_or_create(
        name=row['category'],
        defaults={'slug': row['category'].lower().replace(' ', '-')}
    )

    # Create the Product instance
    Book = Book(
        accession_number=row['Accession Number'],
        author=row['Author'],
        title=row['Title'],
        edition=row['Edition'] if row['Edition'] else None,
        volume=int(row['Volume']) if row['Volume'] else None,
        pages=int(row['Pages']),
        publisher=row['Publisher'],
        year=int(row['Year']),
        isbn=row['ISBN'],
        
    )
    #to save the current product
    Book.save()

print("CSV data has been loaded into the Django database.")
    