from django.db import models

# Create your models here.

class Book(models.Model):
    accession_number = models.CharField(max_length=20, unique=True)    
    author = models.CharField(max_length=255)
    title = models.CharField(max_length=255)
    edition = models.CharField(max_length=50, null=True, blank=True)
    volume = models.IntegerField(null=True, blank=True)
    pages = models.PositiveIntegerField(null=True, blank=True)
    publisher = models.CharField(max_length=255)
    year = models.PositiveIntegerField()
    ISBN = models.CharField(max_length=30, unique=True)


    @property
    def date_to_return(self):
        return 5  # Always return 5

    def __str__(self):
        return self.title
