from django.shortcuts import render, redirect
from django.utils import timezone
from datetime import timedelta
from .models import Book

def borrow_book(request):
    if request.method == "POST":
        accession_number = request.POST.get('accession_number')
        
        try:
            # Case insensitive lookup
            book = Book.objects.get(accession_number__iexact=accession_number)
            
            if book.status == 'available':
                book.status = 'borrowed'
                book.date_borrowed = timezone.now()
                book.days_remaining = 5  
                book.save()

                return redirect('view_books')  
            else:
                return render(request, 'libapp/borrow_book.html', {'error': 'This book is already borrowed.'})
        
        except Book.DoesNotExist:
            return render(request, 'libapp/borrow_book.html', {'error': 'Invalid accession number.'})
    
    return render(request, 'libapp/borrow_book.html')

def merge_sort(books, key_func):
    """
    MergeSort implementation for sorting the books based on a key function (e.g., title, author, publisher, or expected return date).
    This function recursively divides the array and merges the sorted parts back together.
    """
    if len(books) <= 1:
        return books
    
    # Split the books list into two halves
    mid = len(books) // 2
    left_half = merge_sort(books[:mid], key_func)
    right_half = merge_sort(books[mid:], key_func)

    # Merge the sorted halves
    return merge(left_half, right_half, key_func)

def merge(left, right, key_func):
    """
    Merges two sorted lists into one sorted list based on the provided key function.
    """
    sorted_list = []
    
    while left and right:
        # Ensure that we're handling strings and numeric fields separately
        left_key = key_func(left[0])
        right_key = key_func(right[0])
        
        # Compare as strings if the field is a string, else directly compare the numeric or date values
        if isinstance(left_key, str):
            left_key = left_key.lower()
        if isinstance(right_key, str):
            right_key = right_key.lower()
        
        if left_key <= right_key:
            sorted_list.append(left.pop(0))
        else:
            sorted_list.append(right.pop(0))
    
    # Append the remaining elements
    sorted_list.extend(left)
    sorted_list.extend(right)
    
    return sorted_list

def view_books(request):
    # Fetch all borrowed books
    borrowed_books = Book.objects.filter(status='borrowed')
    current_date = timezone.now().date()

    # Calculate expected return dates for each book
    for book in borrowed_books:
        if book.date_borrowed:
            book.expected_return_date = book.date_borrowed + timedelta(days=book.days_remaining)
        else:
            book.expected_return_date = None

    # Sorting criteria: title, author, publisher, days_remaining, or expected_return_date
    sort_field = request.GET.get('sort', 'title')

    if sort_field == 'title':
        borrowed_books = merge_sort(borrowed_books, key_func=lambda book: book.title)
    elif sort_field == 'author':
        borrowed_books = merge_sort(borrowed_books, key_func=lambda book: book.author)
    elif sort_field == 'publisher':
        borrowed_books = merge_sort(borrowed_books, key_func=lambda book: book.publisher)
    elif sort_field == 'days_remaining':
        borrowed_books = merge_sort(borrowed_books, key_func=lambda book: book.days_remaining)
    
    # Apply linear search if a search query is present
    search_query = request.GET.get('search', '')
    if search_query:
        search_query_lower = search_query.lower()
        borrowed_books = [
            book for book in borrowed_books
            if search_query_lower in book.title.lower() or
               search_query_lower in book.author.lower() or
               search_query_lower in book.publisher.lower()
        ]

    # Reset button functionality
    if 'reset' in request.GET:
        return redirect('view_books')  # Redirect to show all borrowed books

    # Calculate return dates and days remaining
    for book in borrowed_books:
        if book.date_borrowed:
            book.return_date = book.date_borrowed + timedelta(days=book.days_remaining)
        else:
            book.return_date = None

        # Calculate the return date as date_borrowed + 5 days
        return_date = (book.date_borrowed + timedelta(days=5)).date()
        days_left = (return_date - current_date).days
        book.days_remaining = max(days_left, 0)

        if days_left <= 0:
            book.status = 'overdue'

        book.save()

    return render(request, 'libapp/view_books.html', {
        'books': borrowed_books,
        'search_query': search_query,
        'sort_field': sort_field,
    })
